package E03Inheritance.P02Zoo;

public class Gorilla extends Mammal{
    public Gorilla(String name) {
        super(name);
    }
}
