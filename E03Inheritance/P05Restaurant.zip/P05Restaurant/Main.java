package E03Inheritance.P05Restaurant;

public class Main {
    public static void main(String[] args) {

    }
}
