package E03Inheritance.P04NeedForSpeed;

public class Main {
    public static void main(String[] args) {

    }
}
