package E03Inheritance.P03PlayersAndMonsters;

public class Knight extends Hero{
    public Knight(String username, int level) {
        super(username, level);
    }
}
