package E03Inheritance.P03PlayersAndMonsters;

public class Wizard extends Hero{
    public Wizard(String username, int level) {
        super(username, level);
    }
}
