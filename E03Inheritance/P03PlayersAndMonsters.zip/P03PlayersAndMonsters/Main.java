package E03Inheritance.P03PlayersAndMonsters;

public class Main {
    public static void main(String[] args) {

    }
}
