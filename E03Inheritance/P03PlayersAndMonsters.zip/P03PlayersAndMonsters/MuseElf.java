package E03Inheritance.P03PlayersAndMonsters;

public class MuseElf extends Elf{
    public MuseElf(String username, int level) {
        super(username, level);
    }
}
