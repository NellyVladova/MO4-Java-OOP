package E03Inheritance.P03PlayersAndMonsters;

public class SoulMaster extends DarkWizard{
    public SoulMaster(String username, int level) {
        super(username, level);
    }
}
