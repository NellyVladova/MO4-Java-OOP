package E03Inheritance.P06Animals;

public class Main {
    public static void main(String[] args) {

    }
}
