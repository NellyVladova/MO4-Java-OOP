package halfLife;

import org.junit.Before;
import org.junit.Test;

public class PlayerTests {
    //TODO: TEST ALL THE FUNCTIONALITY OF THE PROVIDED CLASS Player

    private Player player;
    private Gun gun;

    @Before
    public void setUp(){
        this.gun = new Gun("Maroko", 10);
        this.player = new Player("Ivan", 20);
        this.player.addGun(gun);
    }

    @Test(expected = NullPointerException.class)
    public void testThrowsExceptionWhenTryingToSetNullUsername(){
        new Player(" ", 100);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testThrowsExceptionWhenTryingToSetInvalidHealth(){
        new Player("Pesho", -12);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testThrowsExceptionWhenTryingToModifyUnmodifiableCollection(){
        player.getGuns().remove("Neo100");
    }


}
