package restaurant.repositories;

import restaurant.entities.tables.interfaces.Table;
import restaurant.repositories.interfaces.TableRepository;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class TableRepositoryImpl implements TableRepository<Table> {
    private Map<Integer, Table> tablesMap;

    public TableRepositoryImpl() {
        this.tablesMap = new LinkedHashMap<>();
    }

    @Override
    public Collection<Table> getAllEntities() {
        return Collections.unmodifiableCollection(this.tablesMap.values());
    }

    @Override
    public void add(Table table) {
        this.tablesMap.put(table.getTableNumber(), table);
    }

    @Override
    public Table byNumber(int number) {
        return this.tablesMap.get(number);
    }
}
