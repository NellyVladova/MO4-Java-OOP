package onlineShop.models.products.computers;

import onlineShop.common.constants.ExceptionMessages;
import onlineShop.common.constants.OutputMessages;
import onlineShop.models.products.BaseProduct;
import onlineShop.models.products.components.Component;
import onlineShop.models.products.peripherals.Peripheral;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseComputer extends BaseProduct implements Computer {
    private List<Component> components;
    private List<Peripheral> peripherals;


    public BaseComputer(int id, String manufacturer, String model, double price, double overallPerformance) {
        super(id, manufacturer, model, price, overallPerformance);
        this.components = new ArrayList<>();
        this.peripherals = new ArrayList<>();
    }

    @Override
    public double getOverallPerformance() {
        if (components.isEmpty()) {
            return super.getOverallPerformance();
        }
        double totalOverallPerformance = 0;
        for (Component component : this.components) {
            totalOverallPerformance += component.getOverallPerformance();
        }
        totalOverallPerformance /= components.size();
        return totalOverallPerformance;
    }

    @Override
    public double getPrice() {
        double totalSum = 0;
        for (Peripheral peripheral : this.peripherals) {
            totalSum += peripheral.getPrice();
        }
        for (Component component : this.components) {
            totalSum += component.getPrice();
        }

        return totalSum;
    }

    @Override
    public List<Component> getComponents() {
        return this.components;
    }

    @Override
    public List<Peripheral> getPeripherals() {
        return this.peripherals;
    }

    @Override
    public void addComponent(Component component) {
        if(this.components.contains(component)){
            String exceptionMessage = String.format(ExceptionMessages.EXISTING_COMPONENT, component.getClass().getSimpleName(), this.getClass().getSimpleName(), this.getId());
            throw new IllegalArgumentException(exceptionMessage);
        }
        this.components.add(component);
    }

    @Override
    public Component removeComponent(String componentType) {

        for (Component component : this.components) {
            if (!this.components.getClass().getSimpleName().equals(componentType)) {
                String exceptionMessage = String.format(ExceptionMessages.NOT_EXISTING_COMPONENT, component.getClass().getSimpleName(), this.getClass().getSimpleName(), this.getId());
                throw new IllegalArgumentException(exceptionMessage);
            }
            this.components.remove(component);
            return component;
        }
        return null;
    }

    @Override
    public void addPeripheral(Peripheral peripheral) {
        if(this.peripherals.contains(peripheral)){
            String exceptionMessage = String.format(ExceptionMessages.EXISTING_PERIPHERAL, peripheral.getClass().getSimpleName(), this.getClass().getSimpleName(), this.getId());
            throw new IllegalArgumentException(exceptionMessage);
        }
        this.peripherals.add(peripheral);
    }

    @Override
    public Peripheral removePeripheral(String peripheralType) {
        for (Peripheral peripheral : this.peripherals) {
            if (!this.peripherals.contains(peripheral)) {
                String exceptionMessage = String.format(ExceptionMessages.NOT_EXISTING_PERIPHERAL, peripheral.getClass().getSimpleName(), this.getClass().getSimpleName(), this.getId());
                throw new IllegalArgumentException(exceptionMessage);
            }
            this.peripherals.remove(peripheral);
            return peripheral;
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString()).append(System.lineSeparator());
        sb.append(String.format(" " + OutputMessages.COMPUTER_COMPONENTS_TO_STRING, components.size()))
                .append(System.lineSeparator());

        for (Component component : this.components) {
            sb.append("  ").append(component.toString()).append(System.lineSeparator());
        }
        sb.append(String.format(" " + OutputMessages.COMPUTER_PERIPHERALS_TO_STRING,
                peripherals.size(),
                peripherals.stream().mapToDouble(Peripheral::getOverallPerformance)
                        .average().orElse(0)))
                .append(System.lineSeparator());

        for (Peripheral peripheral : this.peripherals) {
            sb.append("  ").append(peripheral.toString()).append(System.lineSeparator());
        }

        return sb.toString().trim();
    }
}
