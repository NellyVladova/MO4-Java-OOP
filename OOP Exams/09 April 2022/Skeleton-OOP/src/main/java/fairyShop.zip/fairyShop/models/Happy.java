package fairyShop.models;

public class Happy extends BaseHelper{
    private static final int ENERGY_UNITS = 100;

    public Happy(String name) {
        super(name, ENERGY_UNITS);
    }
}
