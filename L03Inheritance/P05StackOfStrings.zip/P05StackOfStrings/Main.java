package L03Inheritance.P05StackOfStrings;

public class Main {
    public static void main(String[] args) {

    }
}
