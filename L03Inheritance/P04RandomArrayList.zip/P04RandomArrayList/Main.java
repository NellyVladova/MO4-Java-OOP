package L03Inheritance.P04RandomArrayList;

public class Main {
    public static void main(String[] args) {

    }
}
