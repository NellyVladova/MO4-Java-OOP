package L03Inheritance.P02MultipleInheritance;

public class Dog extends Animal {
    public void bark(){
        System.out.println("barking...");
    }
}
