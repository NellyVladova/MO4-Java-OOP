package L03Inheritance.P01SingleInheritance;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
