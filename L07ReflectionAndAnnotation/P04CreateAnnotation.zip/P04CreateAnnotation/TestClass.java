package L07ReflectionAndAnnotation.P04CreateAnnotation;

@Subject(categories = {"Test", "Annotations"})
public class TestClass {

}

