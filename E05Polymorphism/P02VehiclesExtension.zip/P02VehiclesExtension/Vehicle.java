package E05Polymorphism.P02VehiclesExtension;

public interface Vehicle {
    String drive(double distance);
    void refuel(double liters);
}
