package E05Polymorphism.P03WildFarm;

public abstract class Felime extends Mammal{

    public Felime(String animalName, String animalType, Double animalWeight, String leavingRegion) {
        super(animalName, animalType, animalWeight, leavingRegion);
    }
}
