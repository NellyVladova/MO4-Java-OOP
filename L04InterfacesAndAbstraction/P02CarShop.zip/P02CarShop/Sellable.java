package L04InterfacesAndAbstraction.P02CarShop;

public interface Sellable extends Car{
    Double getPrice();
}
