package L04InterfacesAndAbstraction.P06Ferrari;

public interface Car {
    String brakes();
    String gas();
}
