package L04InterfacesAndAbstraction.P04SayHelloExtended;

public interface Person {
    String getName();
    String sayHello();
}
