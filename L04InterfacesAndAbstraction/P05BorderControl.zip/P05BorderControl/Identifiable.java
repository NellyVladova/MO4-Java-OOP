package L04InterfacesAndAbstraction.P05BorderControl;

public interface Identifiable {
    String getId();
}
