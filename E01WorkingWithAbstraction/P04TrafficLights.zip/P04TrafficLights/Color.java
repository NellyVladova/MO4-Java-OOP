package E01WorkingWithAbstraction.P04TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW;
}
