package E04InterfacesAndAbstraction.P03BirthdayCelebrations;

public interface Person {
    String getName();
    int getAge();
}
