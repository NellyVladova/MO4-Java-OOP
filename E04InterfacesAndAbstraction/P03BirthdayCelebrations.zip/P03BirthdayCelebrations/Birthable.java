package E04InterfacesAndAbstraction.P03BirthdayCelebrations;

public interface Birthable {
    String getBirthDate();
}
