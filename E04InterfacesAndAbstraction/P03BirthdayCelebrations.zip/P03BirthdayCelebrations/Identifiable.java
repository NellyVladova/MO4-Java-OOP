package E04InterfacesAndAbstraction.P03BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
