package E04InterfacesAndAbstraction.P04FoodShortage;

public interface Person {
    String getName();
    int getAge();
}
