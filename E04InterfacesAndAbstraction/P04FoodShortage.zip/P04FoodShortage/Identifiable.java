package E04InterfacesAndAbstraction.P04FoodShortage;

public interface Identifiable {
    String getId();
}
