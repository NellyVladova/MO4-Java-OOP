package E04InterfacesAndAbstraction.P05Telephony;

public interface Browsable {
    String browse();
}
