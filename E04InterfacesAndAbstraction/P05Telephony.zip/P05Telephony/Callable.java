package E04InterfacesAndAbstraction.P05Telephony;

public interface Callable {
    String call();
}
