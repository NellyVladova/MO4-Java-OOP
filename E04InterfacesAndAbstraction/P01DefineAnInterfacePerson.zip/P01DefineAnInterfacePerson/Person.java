package E04InterfacesAndAbstraction.P01DefineAnInterfacePerson;

public interface Person {
    String getName();
    int getAge();
}
