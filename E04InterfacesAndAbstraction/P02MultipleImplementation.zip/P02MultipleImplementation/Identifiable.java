package E04InterfacesAndAbstraction.P02MultipleImplementation;

public interface Identifiable {
    String getId();
}
