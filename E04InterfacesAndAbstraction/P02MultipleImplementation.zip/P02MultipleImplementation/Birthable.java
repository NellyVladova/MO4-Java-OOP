package E04InterfacesAndAbstraction.P02MultipleImplementation;

public interface Birthable {
    String getBirthDate();
}
